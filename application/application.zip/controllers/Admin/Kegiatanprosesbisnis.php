<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kegiatanprosesbisnis extends CI_Controller{

  public function __construct()
  {
    parent::__construct();
    $this->load->model('admin/m_unit');
    $this->load->model('admin/m_organisasi');
    $this->load->model('admin/m_prosesbisnis');
  }

  function index()
  {
    $data['title'] = 'Kegiatan Dan Proses Bisnis | Simonari';
    $this->load->view('admin/include/header', $data);

    $data['show']     = $this->m_organisasi->getorganisasiunit()->result();
    $data['showunit'] = $this->m_unit->getAllunit()->result();
    $this->load->view('admin/v_kegiatanproses', $data);

    $this->load->view('admin/include/footer');
  }
  function lihatpk($id)
  {
    $data['title'] = 'Detail Perjanjian Kerja | Simonari';
    $this->load->view('admin/include/header', $data);

    $where = array(
      'tbl_unit_kerja.id_unit' => $id
    );

    $data['showPK'] = $this->m_prosesbisnis->getPK($where)->result();
    $this->load->view('admin/v_lihatpk',$data);

    $this->load->view('admin/include/footer');
  }




}
