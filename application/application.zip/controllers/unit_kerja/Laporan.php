<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan extends CI_Controller{

  public function __construct()
  {
    parent::__construct();
    $this->load->model('unit/m_dashboard');
    $this->load->model('core/m_report');
    $this->load->model('unit/m_kegiatanproses');
    //Codeigniter : Write Less Do More
  }

  function index()
  {
    $data['title'] = 'Laporan | Simonari';
    $this->load->view('unit_kerja/include/header', $data);

    $this->load->view('unit_kerja/laporan/v_laporan');

    $this->load->view('unit_kerja/include/footer');
  }

  function reportstatus()
  {
    $data['title'] = 'Report Status | Simonari';
    $this->load->view('unit_kerja/include/header', $data);

    $sess_unit = $this->session->userdata('id_unit');
    $where = array(
      'tbl_unit_kerja.id_unit' => $sess_unit
    );

    $data['data'] = $this->m_dashboard->showPenangananRisk($where)->result();

    $this->load->view('unit_kerja/laporan/v_reportstatus', $data);

    $this->load->view('unit_kerja/include/footer');
  }
  function printreportstatus()
  {
    $this->load->library('pdf/fpdf');
    $this->load->library('MC_TABLE');
    $pdf = new MC_TABLE('L','mm','legal');
    $pdf->addPage();
    $pdf->SetMargins(1,1,1);
    $pdf->AliasNbPages();
    $pdf->SetFont('Arial','B',11);
    $pdf->Image('images/setwapres.png',6,6,20,20);
    $pdf->SetX(40);
    $pdf->MultiCell(70.5,0.5,'Sekretariat Wakil Presiden',0,'L');
    $pdf->SetFont('Helvetica','BI',7);
    $pdf->SetX(40);
    $pdf->MultiCell(70.5,10.5,'Perihal: Report Status  ',0,'L');
    $pdf->SetFont('Arial','',10);

    //------------------- GARIS ATAS -------->
        $pdf->Line(1,30.8,350.6,30.8);
        $pdf->SetLineWidth(0.9);

        $pdf->Line(1,31.8,350.6,31.8);
        $pdf->SetLineWidth(0,6);
    //------------------- GARIS ATAS -------->
    $pdf->ln(5);
    //Table with 20 rows and 4 columns
    $pdf->SetWidths(array(84,85,45,25,60,25,25));
    $pdf->Ln();
    $pdf->Row(array(
            array("Kegiatan"),
            array("Proses Bisnis"),
            array("Risiko"),
            array("Penyebab"),
            array("Kemungkinan"),
            array("Dampak")
    ));



      $session = $this->session->userdata('id_unit');

      $where = array(
        'tbl_unit_kerja.id_unit' => $session,
      );

      foreach($this->m_report->reportResiko($where)->result() as $key ):


      $pdf->Row(array(
          array($key->nama_skp),
          array($key->nama_sop),
          array($key->nama_risk),
          array($key->deskripsi_cause),
          array($key->frekuensi),
          array($key->dampak)
      ));
     endforeach;


    $pdf->output();
  }
  function printdaftarresiko()
  {
    $session = $this->session->userdata('id_unit');

      $where = array(
        'tbl_unit_kerja.id_unit' => $session
      );
    $data['dataSOP'] = $this->m_report->reportResiko($where)->result();
    $this->load->view('unit_kerja/laporan/v_daftarResikoExcel', $data);
  }
  function reportpenanganan()
  {
    $data['title'] = 'Report Rencana Penanganan';
    $this->load->view('unit_kerja/include/header', $data);

    $session = $this->session->userdata('id_unit');
    $where = array(
      'tbl_unit_kerja.id_unit' => $session
    );
    $data['showpenanganan'] = $this->m_report->reportpenanganan($where)->result();

    $this->load->view('unit_kerja/laporan/v_reportpenanganan',$data);

    $this->load->view('unit_kerja/include/footer');
  }
  function reportrencanapenanganan()
  {

    $this->load->library('pdf/fpdf');
    $this->load->library('MC_TABLE');
    $pdf = new MC_TABLE('L','mm','legal');
    $pdf->addPage();
    $pdf->SetMargins(1,1,1);
    $pdf->AliasNbPages();
    $pdf->SetFont('Arial','B',15);
    $pdf->Image('images/setwapres.png',6,6,20,20);
    $pdf->SetX(40);
    $pdf->MultiCell(70.5,0.5,'Sekretariat Wakil Presiden',0,'L');
    $pdf->SetFont('Helvetica','BI',10);
    $pdf->SetX(40);
    $pdf->MultiCell(70.5,10.5,'Perihal: Rencana Penanganan Resiko  ',0,'L');
    $pdf->ln(2);
    $pdf->MultiCell(70.5,10.5,'Monitoring Management Risiko',0,'L');
    $pdf->SetFont('Arial','',10);

    //------------------- GARIS ATAS -------->
        $pdf->Line(1,30.8,350.6,30.8);
        $pdf->SetLineWidth(0.9);

        $pdf->Line(1,31.8,350.6,31.8);
        $pdf->SetLineWidth(0,6);
    //------------------- GARIS ATAS -------->
    $pdf->ln(10);
    //Table with 20 rows and 4 columns
    $pdf->SetFont('Arial','B',11);
    $pdf->Cell(0,0.7,$this->input->get('gedung'),0,1,'L');
    $pdf->ln(3);
    $pdf->setFillColor(128,128,128);
    $pdf->SetFont('Arial','B',8);
    $pdf->Cell(10.7, 15.7, 'NO', 1, 0, 'C');
    $pdf->Cell(82.0, 15.7, 'Resiko', 1, 0, 'C');

    //HEPALA TABEL
    $posisi_x = $pdf->GetX();
    $pdf->cell(231.2,3.5,'Rencana Penanganan',1,0,'C',1);

    $pdf->cell(23.5,3.5,'',1,1,'C',1);

    $pdf->setX($posisi_x);
    $posisi_2 = $pdf->GetX();
    $pdf->cell(70.0,12.2,'Penanganan Yang Akan Dilakukan',1,0,'C', 1);
    $posisi_monitor = $pdf->GetX();
    $pdf->cell(30.4,12.2,'Jadwal Penanganan',1,0,'C', 1);
    $posisi_printer = $pdf->GetX();
    $pdf->cell(45.3,12.2,'Indikator',1,0,'C',1);
    $posisi_scanner = $pdf->GetX();
    $pdf->cell(58.6,12.2,'Penanggung jawab PIC',1,0,'C',1);



    $posisi_x = $pdf->GetX();
    $pdf->cell(50.5,12.2,'Anggaran','LR',1,'C',1);

    //$pdf->Cell(2.7, 0.8, 'Inventaris', 1, 0, 'C');
    //$pdf->Cell(0.9, 0.8, 'Thn', 1, 0, 'C');
    $session = $this->session->userdata('id_unit');
    $where = array(
      'tbl_unit_kerja.id_unit' => $session
    );
    $no = 1;
    foreach($this->m_report->reportpenanganan($where)->result() as $key):
    $pdf->SetWidths(array(10.7,82.0,70.0,30.4,45.3,58.6,50.5));
        $pdf->Row(array(
                    array($no++),
                    array($key->nama_risk),
                    array($key->deskripsi_pengendalian),
                    array($key->plan_mulai),
                    array($key->indikator_output),
                    array($key->pic),
                    array($key->anggaran)
        ));

    endforeach;
      $pdf->output();
  }
  function reportrencanapenangananExcel()
  {
    $session = $this->session->userdata('id_unit');
    $where = array(
      'tbl_unit_kerja.id_unit' => $session
    );
    $data['showpenanganan'] = $this->m_report->reportpenanganan($where)->result();
    $this->load->view('unit_kerja/laporan/v_reportrencanapenangananExcel', $data);
  }

  function reportrealisasipenanganan()
  {
    $data['title'] = 'Laporan Realisasi Penanganan | Simonari';
    $this->load->view('unit_kerja/include/header', $data);

    $this->load->view('unit_kerja/laporan/v_realisasipenanganan');


    $this->load->view('unit_kerja/include/footer');
  }
}
