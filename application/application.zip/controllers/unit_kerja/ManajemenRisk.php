<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ManajemenRisk extends CI_Controller{

  public function __construct()
  {
    parent::__construct();
    $this->load->model('m_login');
    $this->load->model('m_core');
    $this->load->model('unit/m_manajemenrisiko');

    if($this->session->userdata('login') != "ok")
    {
      redirect('login');
    }
  }

  function index()
  {
    $session = $this->session->userdata('id_unit');

			$where = array(
				'tbl_unit_kerja.id_unit' => $session
			);

    $data['title'] = "Manajemen Risk | Simonari";
    $data['data'] = $this->m_manajemenrisiko->showRisk($where)->result();
   
    $data['realisasi'] = $this->m_manajemenrisiko->showRealisasi($where)->result();

    $this->load->view('unit_kerja/include/header', $data);
    $this->load->view('unit_kerja/include/sidebar_risk');
    $this->load->view('unit_kerja/v_manajemenrisiko', $data);
    $this->load->view('unit_kerja/include/footer');
  }

  function showRTP()
  {
    $session = $this->session->userdata('id_unit');

      $where = array(
        'tbl_unit_kerja.id_unit' => $session
      );

    $data['title'] = "Manajemen Risk | Simonari";
    $data['rencana'] = $this->m_manajemenrisiko->showRencana($where)->result();

    $this->load->view('unit_kerja/include/header', $data);
    $this->load->view('unit_kerja/include/sidebar_risk');
    $this->load->view('unit_kerja/v_rtp', $data);
    $this->load->view('unit_kerja/include/footer');
  }

  function showRealisasi()
  {
     $session = $this->session->userdata('id_unit');

      $where = array(
        'tbl_unit_kerja.id_unit' => $session
      );

    $data['title'] = "Manajemen Risk | Simonari";
  
    $data['realisasi'] = $this->m_manajemenrisiko->showRealisasi($where)->result();

    $this->load->view('unit_kerja/include/header', $data);
    $this->load->view('unit_kerja/include/sidebar_risk');
    $this->load->view('unit_kerja/v_realisasi', $data);
    $this->load->view('unit_kerja/include/footer');
  }

  function addRTP($id)
  {
    $session = $this->session->userdata('id_unit');

      $where = array(
        'id_sop' => $id
      );

    $data['title'] = "Data RTP | Simonari";
    $data['data'] = $this->m_core->showWhere('tbl_sop_risk', $where)->result();

    $this->load->view('unit_kerja/include/header', $data);
    $this->load->view('unit_kerja/include/sidebar_risk');
    $this->load->view('unit_kerja/v_tambahrtp', $data);
    $this->load->view('unit_kerja/include/footer');
  }

  function saveRTP()
  {
    $id_sop = $this->input->post('id_sop');
    $deskripsi_rtp = $this->input->post('deskripsi_rtp');
    $plan_mulai = $this->input->post('plan_mulai');
    $plan_selesai = $this->input->post('plan_selesai');
    $indikator = $this->input->post('indikator_output');
    $pic = $this->input->post('pic');

    $data = array(
      'id_sop' => $id_sop,
      'deskripsi_rtp' => $deskripsi_rtp,
      'plan_mulai' => $plan_mulai,
      'plan_selesai' => $plan_selesai,
      'indikator_output' => $indikator,
      'pic' => $pic,
      'status' => 'Open'
    );

    $cek = $this->m_core->insertData('tbl_monitor_rtp', $data);
    if($cek){
      $this->session->set_flashdata('notif', 'Berhasil Menambahkan Data RTP');
      redirect('unit_kerja/manajemenrisk/showRTP');
    } else {
      redirect('home');
    }
  }

  function editRTP($id)
  {
    $session = $this->session->userdata('id_unit');

      $where = array(
        'id_sop' => $id
      );

    $data['title'] = "Data RTP | Simonari";
    $data['data'] = $this->m_core->showWhere('tbl_sop_risk', $where)->result();

    $this->load->view('unit_kerja/include/header', $data);
    $this->load->view('unit_kerja/include/sidebar_risk');
    $this->load->view('unit_kerja/v_tambahrealisasi', $data);
    $this->load->view('unit_kerja/include/footer');
  }

  function updateRTP()
  {
    $id_sop = $this->input->post('id_sop');
    $hambatan = $this->input->post('hambatan');
    $realm_mulai = $this->input->post('real_mulai');
    $real_selesai = $this->input->post('real_selesai');

    $where = array(
      'id_sop' => $id_sop
    );

    $data = array(
      'id_sop' => $id_sop,
      'hambatan' => $hambatan,
      'real_mulai' => $real_mulai,
      'real_selesai' => $real_selesai,
      'status' => 'Close'
    );

    $cek = $this->m_core->updateData($data, $where, 'tbl_monitor_rtp');

    if($cek){
      $this->session->set_flashdata('notif', 'Berhasil Menambahkan Data Realisasi');
      redirect('unit_kerja/manajemenrisk/showRTP');
    } else {
      redirect('home');
    }
  }


}
