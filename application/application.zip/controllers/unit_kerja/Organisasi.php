<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Organisasi extends CI_Controller{

  public function __construct()
  {
    parent::__construct();
    $this->load->model('m_login');
    $this->load->model('m_core');
    $this->load->model('unit/m_organisasi');

    if($this->session->userdata('login') != "ok")
    {
      redirect('login');
    }
  }

  function index()
  {
    $session = $this->session->userdata('id_unit');

			$where = array(
				'tbl_pegawai.id_unit' => $session
			);

      $where1 = array(
        'id_unit' => $session
      );

      $table = "tbl_unit_kerja";

		$data['data'] = $this->m_organisasi->showPegUnit($where)->result();
    $data['keterangan'] = $this->m_core->showWhere($table, $where1)->result();
    $data['title'] = "Organisasi | Simonari";

    $this->load->view('unit_kerja/include/header', $data);
    $this->load->view('unit_kerja/include/sidebar_org');
    $this->load->view('unit_kerja/v_organisasi');
    $this->load->view('unit_kerja/include/footer');
  }

  function editUnit()
  {
    $id_unit = $this->input->post('id_unit');
    $id_unor = $this->input->post('id_unor');
    $nama_unit = $this->input->post('nama_unit');
    $sasaran = $this->input->post('sasaran');
    $iku = $this->input->post('iku');

    $data = array(
      'id_unit' => $id_unit,
      'id_unor' => $id_unor,
      'nama_unit' => $nama_unit,
      'sasaran' => $sasaran,
      'iku' => $iku
    );

    $where = array(
      'id_unit' => $id_unit
    );

    $cek = $this->m_core->updateData($data, $where, 'tbl_unit_kerja');

    if($cek)
    {
      $this->session->set_flashdata('notif', 'Berhasil Mengedit Data Unit Kerja');
      redirect('unit_kerja/organisasi');
    } else {
      redirect('cobacoba');
    }
  }

}
