<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_prosesbisnis extends CI_Model{

  function getPK($where)
  {
    $this->db->select('*');
    $this->db->from('tbl_pk');
    $this->db->join('tbl_unit_kerja', 'tbl_unit_kerja.id_unit = tbl_pk.id_unit');
    $this->db->where($where);

    return $this->db->get();
  }
  function getSPK($where)
  {
    $this->dn->select('*');
    $this->db->select('(select count(nama_skp) from tbl_skp where tbl_skp.id_pk = tbl_pk.id_pk ) as rowpk');

    $this->db->from('tbl_pk');
    $this->db->join('tbl_skp', 'tbl_skp.id_pk = tbl_pk.id_pk', 'left');
    $this->db->join('tbl_unit_kerja', 'tbl_unit_kerja.id_unit = tbl_pk.id_unit','left');

    $this->db->where($where);
    return $this->db->get();

  }

}
