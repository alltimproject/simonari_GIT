</div>
</div>
<div class="footer">
  <h5 class="w3-text-white" >Copyright © 2018 simonari. All rights reserved. </h5>
</div>
<script src="<?= base_url().'assets1/js/jquery.min.js' ?>"></script>
<script src="<?= base_url().'assets1/js/bootstrap.min.js' ?>"></script>
<script src="<?= base_url().'assets1/js/adminlte.min.js' ?>"></script>
<script src="<?= base_url().'assets1/datatables.net/js/jquery.dataTables.min.js' ?>"></script>
<script src="<?= base_url().'assets1/datatables.net-bs/js/dataTables.bootstrap.min.js' ?>"></script>

<script>
$(function () {
  $('#example1').DataTable()
  $('#example2').DataTable({
    'paging'      : true,
    'lengthChange': false,
    'searching'   : false,
    'ordering'    : true,
    'info'        : true,
    'autoWidth'   : false
  })
})
</script>
<script>
$('#notifications').slideDown('slow').delay(2500).slideUp('slow');
</script>
</body>
</html>
