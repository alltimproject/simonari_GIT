<div class="container-fluid">

  <div class="dashboardmenu">
    <div class="card">
      <h2>STATUS</h2>
          <div class="col-md-2" >
            <canvas id="demobar" width="10" height="10"></canvas>
          </div>
          <div class="col-md-2" >
            <canvas id="demobar1" width="10" height="10"></canvas>
          </div>
          <div class="col-md-2" >
            <canvas id="demobar2" width="10" height="10"></canvas>
          </div>
      <div class="box-header with-border">
    </div>
  </div>
  <div class="box">
           <div class="box-header">
             <h3 class="box-title">Data Table With Full Features</h3>
           </div>
           <!-- /.box-header -->
           <div class="box-body">
             <table id="example1" class="table table-bordered table-striped">
               <thead>
               <tr>
                 <th>No</th>
                 <th>Pernyataan Risiko</th>
                 <th>Penyebab</th>
                 <th>Kemungkinan</th>
                 <th>Dampak Tingkat</th>
                 <th>Penanganan</th>
                 <th colspan="2">Tanggal</th>
                 <th>PIC</th>
                 <th>Status</th>
               </tr>
               </thead>
               <tbody>
                 <td>1</td>
                 <td>kurangnya sdm yang bagus </td>
                 <td>Penyebabnya adalah kamu</td>
                 <td>Kemungkinan kita bersama</td>
                 <td>Dampaknya tidak ada sepertinya</td>
                 <td>Penangannan yang berlanjut</td>
                 <td>1990-09-09</td>
                 <td>1990-0-000</td>
                 <td>Wahyu</td>
                 <td class="w3-green">OPEN</td>
               </tbody>
             </table>
           </div>
           <!-- /.box-body -->
         </div>
         <!-- /.box -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.3.0/Chart.bundle.js"></script>
<script  type="text/javascript">

      var ctx = document.getElementById("demobar").getContext("2d");
      var data = {
                labels: ['OPEN'],
                datasets: [
                {
                  label: "Penjualan Smartphone",
                  data: ['10','10'],
                  backgroundColor: [
                    "rgb(238, 9, 2)",
                    "rgb(22, 231, 61)",
                    "rgba(102, 50, 179, 1)",
                    "rgba(201, 29, 29, 1)",
                    "rgba(81, 230, 153, 1)",
                    "rgba(246, 34, 19, 1)"]
                }
                ]
                };

      var myBarChart = new Chart(ctx, {
                type: 'pie',
                data: data,
                options: {
                  responsive: true
              }
            });
    </script>
    <script  type="text/javascript">

          var ctx = document.getElementById("demobar1").getContext("2d");
          var data = {
                    labels: ['OPEN','CLOSE','OPEN','CLOSE'],
                    datasets: [
                    {
                      label: "Penjualan Smartphone",
                      data: ['10','10','70','90'],
                      backgroundColor: [
                        "rgb(238, 9, 2)",
                        "rgb(22, 231, 61)",
                        "rgba(102, 50, 179, 1)",
                        "rgba(201, 29, 29, 1)",
                        "rgba(81, 230, 153, 1)",
                        "rgba(246, 34, 19, 1)"]
                    }
                    ]
                    };

          var myBarChart = new Chart(ctx, {
                    type: 'pie',
                    data: data,
                    options: {
                      responsive: true
                  }
                });
        </script>
        <script  type="text/javascript">

              var ctx = document.getElementById("demobar2").getContext("2d");
              var data = {
                        labels: ['OPEN','CLOSE','OPEN','CLOSE'],
                        datasets: [
                        {
                          label: "Penjualan Smartphone",
                          data: ['10','10','70','90'],
                          backgroundColor: [
                            "rgb(238, 9, 2)",
                            "rgb(22, 231, 61)",
                            "rgba(102, 50, 179, 1)",
                            "rgba(201, 29, 29, 1)",
                            "rgba(81, 230, 153, 1)",
                            "rgba(246, 34, 19, 1)"]
                        }
                        ]
                        };

              var myBarChart = new Chart(ctx, {
                        type: 'pie',
                        data: data,
                        options: {
                          responsive: true
                      }
                    });
            </script>
        <script>
        $(function () {
          $('#example1').DataTable()
          $('#example2').DataTable({
            'paging'      : true,
            'lengthChange': false,
            'searching'   : false,
            'ordering'    : true,
            'info'        : true,
            'autoWidth'   : false
          })
        })
        </script>
