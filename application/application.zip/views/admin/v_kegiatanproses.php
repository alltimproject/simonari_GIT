<div class="row">

  <div class="leftcolumn w3-animate-top">
    <div class="card">
      <div class="w3-panel" style="width:100%">
        <a href="<?= base_url('admin/kegiatanprosesbisnis')  ?>"  class="w3-button w3-block w3-teal">Lihat PK</a>
      </div>
      <div class="w3-panel" style="width:100%">
        <button class="w3-button w3-block w3-teal">Data</button>
      </div>
    </div>

  </div>
  <div class="rightcolumn">
    <div class="card">
      <h6 style="float:right">Cari Berdasarkan Unit:</h6>
      <br>
         </div>
         <!-- TAMPIL CARI pk-->
         <div class="box">
                 <div class="box-header">

                 </div>
                 <!-- /.box-header -->
                 <div class="box-body">
                    <table id="example1" class="table table-bordered table-striped table-hover">
                      <thead>
                  <tr class="bg-blue">
                    <th>Nama Unit</th>
                    <th>Nama Organisasi</th>
                    <th>Lihat PK</th>
                  </tr>
              </thead>
              <tbody>
                <?php
                $no = 1;
                foreach($show as $keyunit):?>
                <tr>
                  <td><?= $keyunit->nama_unit ?></td>
                  <td><?= $keyunit->nama_unor ?></td>
                  <td>
                    <a href="<?= base_url('admin/kegiatanprosesbisnis/lihatpk/'.$keyunit->id_unit) ?>" class="btn btn-info">Lihat PK</a>
                  </td>
                </tr>
               <?php endforeach ?>
              </tbody>
            </table>
          </div>
          </div>
        </div>
