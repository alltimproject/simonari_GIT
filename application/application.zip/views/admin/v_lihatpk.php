<div class="row">

  <div class="leftcolumn w3-animate-top">
    <div class="card">
      <div class="w3-panel" style="width:100%">
        <a href="<?= base_url('admin/kegiatanprosesbisnis')  ?>"  class="w3-button w3-block w3-teal">Lihat PK</a>
      </div>
      <div class="w3-panel" style="width:100%">
        <button class="w3-button w3-block w3-teal">Data</button>
      </div>
    </div>

  </div>
  <div class="rightcolumn">
    <div class="card">
      <h6>Cari Berdasarkan Unit:</h6>

         </div>
         <!-- TAMPIL CARI pk-->
         <div class="box">
                 <div class="box-header">

                 </div>
                 <!-- /.box-header -->
                 <div class="box-body">
                    <table id="example1" class="table table-bordered table-striped table-hover">
                      <thead>
                  <tr class="bg-blue">
                    <th>No</th>
                    <th>Nama IK</th>
                    <th>Target</th>
                    <th>Anggaran</th>
                    <th>Tahun PK</th>
                    <th>Lihat SPK</th>
                  </tr>
              </thead>
              <tbody>
                <?php
                $no = 1;
                foreach($showPK as $keyPK):?>
                <tr>
                  <td><?= $no++ ?></td>
                  <td><?= $keyPK->nama_ik ?></td>
                  <td><?= $keyPK->target ?></td>
                  <td><?= $keyPK->anggaran ?></td>
                  <td><?= $keyPK->tahun_pk ?></td>
                  <td>
                    <a href="#" class="btn btn-info">Lihat</a>
                  </td>
                </tr>

               <?php endforeach; ?>
              </tbody>
            </table>
          </div>
          </div>
        </div>
