
</div>
</div>
<div class="footer">
  <h5 class="w3-text-white" >Copyright © 2018 simonari. All rights reserved. </h5>
</div>
<script src="<?= base_url().'assets1/js/jquery.min.js' ?>"></script>
<script src="<?= base_url().'assets1/js/bootstrap.min.js' ?>"></script>
<script src="<?= base_url().'assets1/js/adminlte.min.js' ?>"></script>
<script src="<?= base_url().'assets1/chart.js/Chart.js' ?>"></script>
<script src="<?= base_url().'assets1/datatables.net/js/jquery.dataTables.min.js' ?>"></script>
<script src="<?= base_url().'assets1/datatables.net-bs/js/dataTables.bootstrap.min.js' ?>"></script>
<script type="text/javascript">
  $(function(){
    $('#pernyataanRisk').DataTable({
      'paging'      : false,
      'lengthChange': false,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    });
    $('#pegawai').DataTable({
      'paging'      : false,
      'lengthChange': false,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    });
  });
</script>

<script type="text/javascript">
  $('.tooltip-demo').tooltip({
    selector: "[data-toggle=tooltip]",
    container: "body"
  });
</script>

<script type="text/javascript">
  $(document).ready(function(){
    $('.editPK').hide();
    $('.editSKP').hide();
    $('.editSOP').hide();
  });
</script>

<script>
$('#notifications').slideDown('slow').delay(4000).slideUp('slow');
</script>

<script type="text/javascript">
  $(document).on('click', '#pilihPK', function(e) {
    $('.editPK').slideDown();
    $('html, body').animate({
      scrollTop: $('.editPK').offset().top
    });
    document.getElementById("nama_ik").value = $(this).attr('data-nama_ik');
    document.getElementById("target").value = $(this).attr('data-target');
    document.getElementById("anggaran").value = $(this).attr('data-anggaran');
    document.getElementById("tahun_pk").value = $(this).attr('data-tahun_pk');
    document.getElementById("id_pk").value = $(this).attr('data-id_pk');
    
  });

  $(document).on('click', '#pilihSKP', function(e) {
    $('.editSKP').slideDown();
    $('html, body').animate({
      scrollTop: $('.editSKP').offset().top
    });
    document.getElementById("nama_skp").value = $(this).attr('data-nama_skp');
    document.getElementById("target_volume").value = $(this).attr('data-target_volume');
    document.getElementById("target_mutu").value = $(this).attr('data-target_mutu');
    document.getElementById("target_waktu").value = $(this).attr('data-target_waktu');
    document.getElementById("target_biaya").value = $(this).attr('data-target_biaya');
    document.getElementById("id_skp").value = $(this).attr('data-id_skp');
    
  });

  $(document).on('click', '#pilihSOP', function(e) {
    $('.editSOP').slideDown();
    $('html, body').animate({
      scrollTop: $('.editSOP').offset().top
    });
    document.getElementById("nama_sop").value = $(this).attr('data-nama_sop');
    document.getElementById("nama_risk").value = $(this).attr('data-nama_risk');
    document.getElementById("sisa_risk").value = $(this).attr('data-sisa_risk');
    document.getElementById("frekuensi").value = $(this).attr('data-frekuensi');
    document.getElementById("dampak").value = $(this).attr('data-dampak');
    document.getElementById("deskripsi_cause").value = $(this).attr('data-deskripsi_cause');
    document.getElementById("kategori_cause").value = $(this).attr('data-kategori_cause');
    document.getElementById("deskripsi_pengendalian").value = $(this).attr('data-deskripsi_pengendalian');
    document.getElementById("id_sop").value = $(this).attr('data-id_sop');
    
  });

  $(document).on('click', '#cancelUpdatePK', function(e){
    $('.editPK').slideUp();
  });
  $(document).on('click', '#cancelUpdateSKP', function(e){
    $('.editSKP').slideUp();
  });
  $(document).on('click', '#cancelUpdateSOP', function(e){
    $('.editSOP').slideUp();
  });
</script>


<script type="text/javascript">
  $(document).ready(function(){
    var count = 1;
    $('#add-pk').click(function(){
      count = count + 1;
      var html_code = "<tr id='baris"+count+"'>";
      html_code += "<td><textarea name='nama_ik[]' class='form-control' style='height: 80px'></textarea></td>";
      html_code += "<td><textarea name='target[]' class='form-control' style='height: 80px'></textarea></td>";
      html_code += "<td><input type='number' class='form-control' name='anggaran[]'></td>";
      html_code += "<td><input type='number' class='form-control' name='tahun_pk[]' maxlength='4'></td>";
      html_code += "<td><button id='"+count+"' type='button' name='remove' class='btn btn-danger btn-md remove'>-</button></td>";
      html_code += "</tr>";
      $('#tb-pk').append(html_code);
    });
    $(document).on('click', '.remove', function(){
      var button_id = $(this).attr("id");
      $('#baris'+button_id+'').remove();
    });
  });
</script>

<script type="text/javascript">
  $(document).ready(function(){
    var count = 1;
    $('#add-skp').click(function(){
      count = count + 1;
      var html_code = "<tr id='baris"+count+"'>";
      html_code += "<td></td>";
      html_code += "<td><textarea name='nama_skp[]' class='form-control' style='height:100px;'></textarea></td>";
      html_code += "<td><textarea name='target_volume[]' class='form-control' style='height:100px;'></textarea></td>";
      html_code += "<td><textarea name='target_mutu[]' class='form-control' style='height:100px;'></textarea></td>";
      html_code += "<td><textarea name='target_waktu[]' class='form-control' style='height:100px;'></textarea></td>";
      html_code += "<td><input type='text' class='form-control' name='target_biaya[]'></td>";
      html_code += "<td><button id='"+count+"' type='button' name='remove' class='btn btn-danger btn-md remove'> - </button></td>";
      html_code += "</tr>";
      $('#tb-skp').append(html_code);
    });
    $(document).on('click', '.remove', function(){
      var button_id = $(this).attr("id");
      $('#baris'+button_id+'').remove();
    });
  });
</script>

<script type="text/javascript">
  $(document).ready(function(){
    var count = 1;
    $('#add-sop').click(function(){
      count = count + 1;
      var html_code = "<tr id='baris"+count+"'>";
      html_code += "<td><textarea name='nama_sop[]' class='form-control' style='height:100px'></textarea></td>";
      html_code += "<td><textarea name='nama_risk[]' class='form-control' style='height:100px'></textarea></td>";
      html_code += '<td><select name="frekuensi[]" class="form-control frekuensi"><option value=""></option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option></select></td>'; 
      html_code += '<td><select name="dampak[]" class="form-control dampak"><option value=""></option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option></select></td>';
      html_code += "<td><textarea name='deskripsi_cause[]' class='form-control' style='height:100px'></textarea></td>";
      html_code += '<td><select name="kategori_cause[]" class="form-control"><option value="">--Pilih Kategori--</option><option value="Man">Man</option><option value="Money">Money</option><option value="Method">Method</option><option value="Machine">Machine</option><option value="Material">Material</option></select></td>';
      html_code += "<td><textarea name='deskripsi_p_exist[]' class='form-control' style='height:100px'></textarea></td>";
      html_code += "<td><textarea name='sisa_risk[]' class='form-control' style='height:100px'></textarea></td>";
      html_code += "<td><button id='"+count+"' type='button' name='remove' class='btn btn-danger btn-md remove'> - </button></td>";
      html_code += "</tr>";
      $('#tb-sop').append(html_code);
    });
    $(document).on('click', '.remove', function(){
      var button_id = $(this).attr("id");
      $('#baris'+button_id+'').remove();
    });
  });
</script>

<script type="text/javascript">
  $(document).ready(function(){
    $('#selectPK').on('change', function(){
      var id_pk = $(this).val();
      if (id_pk == '') {
        $('#selectSKP').prop('disabled', true);
      } else {
        $('#selectSKP').prop('disabled', false);
        var link = "<?= base_url('unit_kerja/kegiatanproses/getSKP') ?>"
        $.ajax({
          url: link,
          type: "POST",
          data: {'id_pk': id_pk},
          dataType: 'json',
          success: function(data){
            $('#selectSKP').html(data);
          },
          error: function(){
            alert("Belum ada SKP");
          }
        });
      }
    });
  });
</script>

<script type="text/javascript">
  $(document).ready(function(){
    $('#alertOrg').hide('fast');
    $('#updateB').hide('fast');
    $('#cancelB').hide('fast');

    $('#editSasaran').click(function(){
      $('#sasaran').prop('disabled', false);
      $('#updateB').show();
      $('#cancelB').show();
      return false;
    });
    $('#editIKU').click(function(){
      $('#ikuForm').prop('disabled', false);
      $('#updateB').show();
      $('#cancelB').show();
      return false;
    });
    $('#cancelB').click(function(){
      $('#sasaran').prop('disabled', true);
      $('#ikuForm').prop('disabled', true);
      $('#updateB').hide();
      $('#cancelB').hide();
      return false;
    });
    $('#form-org').submit(function(){

      if($('#sasaran').val() == '')
      {
        $('#alertOrg').fadeIn().html('<strong> Field tidak boleh kosong  </strong>');
        return false;
      } else if($('#ikuForm').val() == '')
      {
        $('#alertOrg').fadeIn().html('<strong> Field tidak boleh kosong  </strong>');
        return false;
      } else 
      {
        $('#sasaran').prop('disabled', false);
        $('#ikuForm').prop('disabled', false);
        return true;
      }
    });
  });
</script>



<script type="text/javascript">
  $(function(){
    $('.contentPegawai').hide();
    $('#unitKerja').click(function(){
      $('.contentPegawai').slideUp();
      $('.contentUnit').slideDown();
    });
    $('#dataPegawai').click(function(){
      $('.contentUnit').slideUp();
      $('.contentPegawai').slideDown();
    });
  });
</script>

<script type="text/javascript">
  $(function(){

    var halaman = $('#halaman').val();

    if(halaman == 'okpk')
    {
      $('.contentPK').show();
      $('.contentSOP').hide();
      $('.contentSKP').hide();
    }else if(halaman == 'okskp')
    {
      $('.contentPK').hide();
      $('.contentSOP').hide();
      $('.contentSKP').show();
    }else if(halaman == 'oksop')
    {
      alert(halaman);
    } else {
      $('.contentSOP').hide();
      $('.contentSKP').hide();
    }

    $('#PK').click(function(){
      $('.contentPK').slideDown();
      $('.contentSOP').slideUp();
      $('.contentSKP').slideUp();
      $('.editPK').hide();
      $('.editSKP').hide();
      $('.editSOP').hide();
    });
    $('#SKP').click(function(){
      $('.contentPK').slideUp();
      $('.contentSOP').slideUp();
      $('.contentSKP').slideDown();
      $('.editPK').hide();
      $('.editSKP').hide();
      $('.editSOP').hide();
    });
    $('#SOP').click(function(){
      $('.contentPK').slideUp();
      $('.contentSOP').slideDown();
      $('.contentSKP').slideUp();
      $('.editPK').hide();
      $('.editSKP').hide();
      $('.editSOP').hide();
    });
  });
</script>


</body>
</html>
