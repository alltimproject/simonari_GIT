<?php
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=data-daftarresiko.xls");//ganti nama sesuai keperluan
header("Pragma: no-cache");
header("Expires: 0");
//disini script laporan anda
?>
<?php
$nopk = 1;
$noskp = 1;
$nosop = 1;
$jum = 1;
$jum1 = 1;
$no = 1;
?>
<div class="contentSOP">
	<legend><h3>DAFTAR RESIKO
	</h3></legend>
	<h2>Nama Unt : <?php echo $this->session->userdata('nama_unit') ?></h2>
	<table border="1" class="table table-bordered table-hover">
		<tr class="bg-blue">
			<th>No</th>
			<th>Kegiatan</th>
			<th>Proses Bisnis</th>
			<th>Resiko</th>
			<th>Penyebab</th>
			<th>Pengendalian/Penanganan Yang sudah Ada</th>
			<th>Sisa Resiko</th>
			<th>Kemungkinan</th>
			<th>Dampak</th>
			<th>PK</th>
		</tr>

<?php foreach ($dataSOP as $sop) { ?>
		<tr>
			<?php

				if($jum1 <= 1)
				{
					$jmlsop = $sop->rowskp;
					if ($jmlsop == 0) {
						$jmlsop = 1;
					}
			?>
				<td rowspan="<?= $jmlsop ?>"><?= $nosop ?></td>
				<td rowspan="<?= $jmlsop ?>">	</td>
			<?php
					$jum1 = $sop->rowskp;
					$nosop++;
				} else {
					$jum1 = $jum1 - 1;
				}
			 ?>

			 <td><?= $sop->nama_sop ?></td>
			 <td><?= $sop->nama_risk ?></td>
			 <td><?= $sop->deskripsi_cause ?></td>
			 <td><?= $sop->deskripsi_pengendalian ?></td>
			 <td><?= $sop->sisa_risk ?></td>
			 <td><?= $sop->frekuensi ?></td>
			 <td><?= $sop->dampak ?></td>
			 <td><?= $sop->nama_ik ?></td>

		</tr>
<?php  } ?>
	</table>
</div>

</div>
</div>
