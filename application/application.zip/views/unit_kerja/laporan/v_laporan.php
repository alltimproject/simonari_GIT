<div class="row">

  <div class="leftcolumn w3-animate-top">
    <div class="card">
      <div class="w3-panel" style="width:100%">
        <a href="<?= base_url('unit_kerja/laporan/reportstatus')  ?>"  class="w3-button w3-block w3-teal">Laporan Daftar Risiko</a>
      </div>
      <div class="w3-panel" style="width:100%">
        <a href="<?= base_url('unit_kerja/laporan/reportpenanganan')  ?>"  class="w3-button w3-block w3-teal">Laporan Rencana Penanganan Risiko</a>
      </div>
      <div class="w3-panel" style="width:100%">
        <a href="<?= base_url('unit_kerja/laporan/reportrealisasipenanganan')  ?>"  class="w3-button w3-block w3-teal">Laporan Realisasi Penanganan Risiko</a>
      </div>
    </div>

  </div>
