<div class="row">

  <div class="leftcolumn w3-animate-top">
    <div class="card">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Laporan Daftar Realisasi Penanganan</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <center><a href="<?= base_url('unit_kerja/laporan/reportrencanapenanganan')  ?>" target="_blank" class="btn btn-info">Print PDF</a>
            <a href="<?= base_url('unit_kerja/laporan/reportrencanapenangananExcel')  ?>" target="_blank" class="btn btn-info">Print Excel</a></center>
          </div>
        </div>
      </div>
  <div class="rightcolumn">
    <div class="card">
      <div class="box">
        <div class="box-header">
          <div class="box-title">
            <h3>Laporan Daftar Realisasi Penanganan</h3>
          </div>
        </div>
        <div class="box-body">
          <table id="pernyataanRisk" class="table table-responsive table-striped table-hover table-bordered">
            <thead>
              <tr class="bg-blue">
                <th>No</th>
                <th>Resiko</th>
                <th>Penanganan yang telah dilakukan</th>
                <th>jadwal Penanganan</th>
                <th>Indikator output</th>
                <th>PIC</th>
                <th>Anggaran</th>
                <th>Hambatan</th>
              </tr>
            </thead>
            <tbody>

              <?php
              $no = 1;
              foreach ($showpenanganan as $key): ?>
                <tr>
                  <td><?= $no++ ?></td>
                  <td><?= $key->nama_risk ?></td>
                  <td><?= $key->deskripsi_pengendalian ?></td>
                  <td><?= $key->plan_mulai ?></td>
                  <td><?= $key->indikator_output ?></td>
                  <td><?= $key->pic ?></td>
                  <td><?= $key->anggaran ?></td>

                </tr>
              <?php endforeach; ?>
            </tbody>

          </table>
        </div>

      </div>

    </div>
  </div>
