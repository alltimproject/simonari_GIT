<?php
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=data-rencanapenanganan.xls");//ganti nama sesuai keperluan
header("Pragma: no-cache");
header("Expires: 0");
//disini script laporan anda
?>
<div class="row">
  <div class="leftcolumn w3-animate-top">
  <div class="rightcolumn">
    <div class="card">
      <div class="box">
        <div class="box-header">
          <div class="box-title">
            <h3>Laporan Daftar Rencana Penanganan</h3>
          </div>
        </div>
        <div class="box-body">
          <table border="1" id="pernyataanRisk" class="table table-responsive table-striped table-hover table-bordered">
            <thead>
              <tr class="bg-blue">
                <th>No</th>
                <th>Resiko</th>
                <th>Penanganan yang akan di lakukan</th>
                <th>jadwal Penanganan</th>
                <th>Indikator output</th>
                <th>PIC</th>
                <th>Anggaran</th>
              </tr>
            </thead>
            <tbody>

              <?php
              $no = 1;
              foreach ($showpenanganan as $key): ?>
                <tr>
                  <td><?= $no++ ?></td>
                  <td><?= $key->nama_risk ?></td>
                  <td><?= $key->deskripsi_pengendalian ?></td>
                  <td><?= $key->plan_mulai ?></td>
                  <td><?= $key->indikator_output ?></td>
                  <td><?= $key->pic ?></td>
                  <td><?= $key->anggaran ?></td>

                </tr>
              <?php endforeach; ?>
            </tbody>

          </table>
        </div>

      </div>

    </div>
  </div>
