  <?php foreach ($data as $key): ?>
    <?= $key->id_pk ?>
    <?= $key->id_skp ?>
  <?php endforeach ?>
