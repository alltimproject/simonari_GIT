<?php
	$nopk = 1;
  $noskp = 1;
  $nosop = 1;
	$jum = 1;
  $jum1 = 1;
	$no = 1;
?>


<script src="<?= base_url().'assets1/includeJS/kegiatanproses.js' ?>"></script>
  
  <div class="rightcolumn">
    <div class="card">
    <div class="contentPK">
      <legend>
        <h3>Data PK
          <div class="pull-right"><a href="<?= base_url('unit_kerja/kegiatanproses/addPK') ?>" class="btn btn-md btn-info">Tambah PK</a></div>
        </h3>
      </legend>


<!-- Halaman Edit PK -->
      <div class="editPK">
      <h3>Edit PK</h3>
      <form action="<?= base_url('unit_kerja/kegiatanproses/updatePK') ?>" method="post">
        <table class="table table-bordered table-responsive" id="tb-pk">
            <tr style="background-color: grey; color: white">
                <th width="30%">IK</th>
                <th width="30%">Target</th>
                <th width="20%">Anggaran</th>
                <th width="10%">Tahun PK</th>
                <th width="10%"></th>
            </tr>
            <tr>
                <td class="ik"><textarea name="nama_ik" class="form-control" style="height: 80px" id="nama_ik"></textarea></td>
                <td class="target"><textarea name="target" class="form-control" style="height: 80px" id="target"></textarea></td>
                <td class="anggaran"><input type="number" class="form-control" name="anggaran" id="anggaran"></td>
                <td class="tahun_pk"><input type="number" class="form-control" name="tahun_pk" maxlength="4" id="tahun_pk"></td>
                <td>
                  <center>
                    <button type="submit" class="btn btn-md btn-success"><i class="fa fa-save"></i></button>
                    <button type="button" class="btn btn-md btn-danger" id="cancelUpdatePK"><i class="fa fa-close"></i></button>
                  </center>
                </td>
            </tr>
            <input type="hidden" id="id_pk" name="id_pk">
          </table>   
        </form>
      </div>
<!-- -->     

<!-- Halaman Data PK --> 
      
				<div class="table-responsive">
					<table class="table table-bordered table-hover">
						<thead>
							<tr class="bg-blue">
		            <th>No</th>
		            <th width="35%">IK</th>
		            <th>Target</th>
		            <th>Anggaran</th>
		            <th>Tahun PK</th>
		            <th>Aksi</th>
		          </tr>
						</thead>
						<tbody>
							<?php foreach ($dataPK as $pk): ?>
		            <tr>
		              <td><?= $nopk++ ?></td>
		              <td><?= $pk->nama_ik ?></td>
		              <td><?= $pk->target ?></td>
		              <td><?= $pk->anggaran ?></td>
		              <td><?= $pk->tahun_pk ?></td>
		              <td>
		                <a id="pilihPK" data-id_pk="<?= $pk->id_pk ?>" data-nama_ik="<?= $pk->nama_ik ?>" data-target="<?= $pk->target ?>" data-anggaran="<?= $pk->anggaran ?>" data-tahun_pk="<?= $pk->tahun_pk ?>" class="btn btn-success btn-sm">Edit PK</a>
		              </td>
		            </tr>
		          <?php endforeach; ?>
						</tbody>
	        </table>
				</div>
      </div>
<!-- Batas -->

<!-- Halaman SKP -->
      <div class="contentSKP">
       <legend><h3>Data SKP
        <div class="pull-right"><a href="<?= base_url('unit_kerja/kegiatanproses/addSKP') ?>" class="btn btn-md btn-info">Tambah SKP</a></div>
        </h3></legend>

<!-- Halaman Edit SKP -->
        <div class="editSKP">
          <h3>Edit SKP</h3>
          <form action="<?= base_url('unit_kerja/kegiatanproses/updateSKP') ?>" method="post">
            <table class="table table-bordered" id="tb-skp">
              <tr>
                <th width="20%">SKP</th>
                <th width="20%">Target Volume</th>
                <th width="20%">Target Mutu</th>
                <th width="15%">Target Waktu</th>
                <th width="15%">Target Biaya</th>
                <th></th>
              </tr>
              <tr>
                <td><textarea name="nama_skp" class="form-control" style="height:100px;" id="nama_skp"></textarea></td>
                <td><textarea name="target_volume" class="form-control" style="height:100px;" id="target_volume"></textarea></td>
                <td><textarea name="target_mutu" class="form-control" style="height:100px;" id="target_mutu"></textarea></td>
                <td><textarea name="target_waktu" class="form-control" style="height:100px;" id="target_waktu"></textarea></td>
                <td><input type="number" class="form-control" name="target_biaya" id="target_biaya"></td>
                <td>
                  <input type="hidden" name="id_skp" id="id_skp">
                  <button type="submit" name="submit" class="btn btn-success btn-md"><span class="fa fa-save"></span></button>
                  <button type="button" class="btn btn-danger btn-md" id="cancelUpdateSKP"><span class="fa fa-close"></span></button>
                </td>
              </tr>
            </table>
          </form>
          </div>
<!-- Akhir halaman Edit SKP -->

        <table class="table  table-bordered table-hover">
          <tr class="bg-blue">
            <th>No</th>
            <th>Nama PK</th>
            <th>Nama SKP</th>
            <th>Target Volume</th>
            <th>Target Mutu</th>
            <th>Target Waktu</th>
            <th>Target Biaya</th>
            <th>Aksi</th>
          </tr>

      <?php foreach ($dataSKP as $skp) { ?>
          <tr>
            <?php

              if($jum <= 1)
              {
                $jmlrow = $skp->rowpk;
                if ($jmlrow == 0) {
                  $jmlrow = 1;
                }
            ?>
              <td rowspan="<?= $jmlrow ?>"><?= $noskp ?></td>
              <td rowspan="<?= $jmlrow ?>"><?= $skp->nama_ik ?></td>
            <?php
                $jum = $skp->rowpk;
                $noskp++;
              } else {
                $jum = $jum - 1;
              }
             ?>

             <td><?= $skp->nama_skp ?></td>
             <td><?= $skp->target_volume ?></td>
             <td><?= $skp->target_mutu ?></td>
             <td><?= $skp->target_waktu ?></td>
             <td><?= $skp->target_biaya ?></td>
             <td>
              <a id="pilihSKP" data-id_skp="<?= $skp->id_skp ?>" data-nama_skp="<?= $skp->nama_skp ?>" data-target_volume="<?= $skp->target_volume ?>" data-target_waktu="<?= $skp->target_waktu ?>" data-target_mutu="<?= $skp->target_mutu ?>" data-target_biaya="<?= $skp->target_biaya ?>" class="btn btn-success btn-sm">Edit SKP</a>
             </td>

          </tr>
      <?php  } ?>
        </table>
      </div>

      <div class="contentSOP">
        <legend><h3>Data SOP
        <div class="pull-right"><a href="<?= base_url('unit_kerja/kegiatanproses/addsop') ?>" class="btn btn-md btn-info" align="right">Tambah SOP</a></div>
        </h3></legend>

        <div class="editSOP">
          <h3 align="right">Edit SOP</h3>
          <form class="form-sop" action="<?= base_url('unit_kerja/kegiatanproses/updateSOP') ?>" method="post">
            <table class="table table-bordered" id="tb-sop">
                <tr>
                  <th width="25%">SOP</th>
                  <th width="25%">Risiko</th>
                  <th width="25%">Kemungkinan</th>
                  <th width="25%">Dampak</th>
                  <th width="25%"></th>
                </tr>
                <tr>
                  <td><textarea id="nama_sop" name="nama_sop" class="form-control" style="height:100px"></textarea></td>
                  <td><textarea id="nama_risk" name="nama_risk" class="form-control" style="height:100px"></textarea></td>
                  <td><select id="frekuensi" name="frekuensi" class="form-control frekuensi"><option value=""></option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option></select></td>
                  <td><select id="dampak" name="dampak" class="form-control dampak"><option value=""></option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option></select></td>
                </tr>
                <tr>
                  <th>Penyebab</th>
                  <th>Kategori</th>
                  <th>Pengendalian</th>
                  <th>Sisa Risk</th>
                </tr>
                <tr>
                  <td><textarea id="deskripsi_cause" name="deskripsi_cause" class="form-control" style="height:100px"></textarea></td>
                  <td><select id="kategori_cause" name="kategori_cause" class="form-control"><option value="">--Pilih Kategori--</option><option value="Man">Man</option><option value="Money">Money</option><option value="Method">Method</option><option value="Machine">Machine</option><option value="Material">Material</option></select></td>
                  <td><textarea id="deskripsi_pengendalian" name="deskripsi_pengendalian" class="form-control" style="height:100px"></textarea></td>
                  <td><textarea id="sisa_risk" name="sisa_risk" class="form-control" style="height:100px"></textarea></td>
                </tr>
                <tr>
                  <td colspan="4">
                    <center>
                      <input type="hidden" name="id_sop" id="id_sop">
                      <button type="submit" name="submit" class="btn btn-success btn-md">Edit<span class="fa fa-save"></span></button>
                      <button type="button" class="btn btn-danger btn-md" id="cancelUpdateSOP">Cancel<span class="fa fa-save"></span></button>
                    </center>
                  </td>
                </tr>
            </table>
          </form>
        </div>

        <table class="table table-bordered table-hover">
          <tr class="bg-blue">
            <th>No</th>
            <th>Nama SKP</th>
            <th>Nama SOP</th>
            <th>Nama Risk</th>
            <th>Frekuensi</th>
            <th>Dampak</th>
						<th>Hitung</th>
            <th>Sisa Risk</th>
            <th>Aksi</th>
          </tr>

      <?php foreach ($dataSOP as $sop) { ?>
          <tr>
            <?php

              if($jum1 <= 1)
              {
                $jmlsop = $sop->rowskp;
                if ($jmlsop == 0) {
                  $jmlsop = 1;
                }
            ?>
              <td rowspan="<?= $jmlsop ?>"><?= $nosop ?></td>
              <td rowspan="<?= $jmlsop ?>">
                <div class="tooltip-demo"><span data-toggle="tooltip" data-placement="left" title="Nama IK : <?= $sop->nama_ik ?>"><?= $sop->nama_skp ?></span></div>
              </td>
            <?php
                $jum1 = $sop->rowskp;
                $nosop++;
              } else {
                $jum1 = $jum1 - 1;
              }
             ?>

             <td><?= $sop->nama_sop ?></td>
             <td><?= $sop->nama_risk ?></td>
             <td><?= $sop->frekuensi ?></td>
             <td><?= $sop->dampak ?></td>
						 <td><?= $sop->hitung ?></td>
             <td><?= $sop->sisa_risk ?></td>

             <td>
              <a id="pilihSOP" data-id_sop="<?= $sop->id_sop ?>" data-nama_sop="<?= $sop->nama_sop ?>" data-nama_risk="<?= $sop->nama_risk ?>" data-sisa_risk="<?= $sop->sisa_risk ?>" data-frekuensi="<?= $sop->frekuensi ?>" data-dampak="<?= $sop->dampak ?>" data-deskripsi_cause="<?= $sop->deskripsi_cause ?>" data-kategori_cause="<?= $sop->kategori_cause ?>" data-deskripsi_pengendalian="<?= $sop->deskripsi_pengendalian ?>" class="btn btn-success btn-sm">Edit SOP</a>
             </td>
          </tr>
      <?php  } ?>
        </table>
      </div>

    </div>
  </div>

  <?php if($this->session->flashdata('notif') ){ ?>
                <div class="callout callout-success" id="notifications">
                <?php echo $this->session->flashdata('notif'); ?>
                </div>
                <?php } ?>

<div class="halaman" id="halaman"><?= $this->session->flashdata('halaman') ?></div>
