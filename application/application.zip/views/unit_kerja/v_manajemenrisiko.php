<?php

  $jum1 = 1;
  $nosop = 1;

 ?>

<div class="rightcolumn">
  <div class="card">

    <div class="contentRISK">
       <legend>Daftar Risiko</legend>
        <table id="pegawai" class="table table-bordered table-hover">
          <tr class="bg-blue">
            <th>No</th>
            <th>Nama SKP</th>
            <th>Nama SOP</th>
            <th>Nama Risk</th>
            <th>Penyebab</th>
            <th>Pengendalian</th>
            <th>Sisa Risk</th>
            <th>Frekuensi</th>
            <th>Dampak</th>
            <th>Hitung</th>
            <th>Tingkat</th>
          </tr>

      <?php foreach ($data as $risk) { ?>
          <tr>
            <?php

              if($jum1 <= 1)
              {
                $jmlsop = $risk->rowskp;
                if ($jmlsop == 0) {
                  $jmlsop = 1;
                }
            ?>
              <td rowspan="<?= $jmlsop ?>"><?= $nosop ?></td>
              <td rowspan="<?= $jmlsop ?>"><?= $risk->nama_skp ?></td>
            <?php
                $jum1 = $risk->rowskp;
                $nosop++;
              } else {
                $jum1 = $jum1 - 1;
              }
             ?>

             <td><?= $risk->nama_sop ?></td>
             <td><?= $risk->nama_risk ?></td>      
             <td><?= $risk->deskripsi_cause ?></td>
             <td><?= $risk->deskripsi_pengendalian ?></td>
             <td><?= $risk->sisa_risk ?></td>
             <td><?= $risk->frekuensi ?></td>
             <td><?= $risk->dampak ?></td>
             <td><?= $risk->hitung ?></td>
             <td>
                <?php 

                    if($risk->hitung == 0)
                    {
                      echo "<small>NULL</small>";
                    }elseif($risk->hitung >= 1 && $risk->hitung <= 5)
                    {
                      echo "<small>Sangat Rendah</small>";
                    } elseif ($risk->hitung >= 6 && $risk->hitung <= 11) 
                    {
                      echo "<small>Rendah</small>";
                    } elseif ($risk->hitung >= 12 && $risk->hitung <= 15)
                    {
                      echo "<small>Sedang</small>";
                    } elseif ($risk->hitung >= 16 && $risk->hitung <= 19) {
                      echo "<small>Tinggi</small>";
                    } else
                    {
                      echo "<small>Sangat Tinggi</small>";
                    }
                ?>
             </td>
          </tr>
      <?php  } ?>
        </table>
    </div>

    <!-- End Table -->

  </div>
</div>

<?php if($this->session->flashdata('notif') ){ ?>
                <div class="callout callout-success" id="notifications">
                <?php echo $this->session->flashdata('notif'); ?>
                </div>
                <?php } ?>
