<div class="rightcolumn">
  <?php $noreal = 1; ?>
  <div class="card">
       <legend>Realisasi Penanganan Risiko</legend>
        <table id="pegawai" class="table table-bordered table-hover">
          <tr class="bg-blue">
            <th>No</th>
            <th>Risiko</th>
            <th>Penyebab</th>
            <th>Kemungkinan</th>
            <th>Dampak</th>
            <th>Tingkat</th>
            <th>Pengendalian</th>
            <th>Penanganan</th>
            <th>Mulai</th>
            <th>Selesai</th>
            <th>Output</th>
            <th>PIC</th>
            <th>Anggaran</th>
            <th>Aksi</th>
          </tr>

      <?php foreach ($realisasi as $real): ?>
            <tr>
              <td><?= $noreal++ ?></td>
              <td><?= $real->nama_risk ?></td>
              <td><?= $real->deskripsi_cause ?></td>
              <td><?= $real->frekuensi ?></td>      
              <td><?= $real->dampak ?></td>
              <td><?= $real->hitung ?></td>
              <td><?= $real->deskripsi_pengendalian ?></td>
              <td><?= $real->deskripsi_rtp ?></td>
              <td><?= $real->plan_mulai ?></td>
              <td><?= $real->plan_selesai ?></td>
              <td><?= $real->indikator_output ?></td>
              <td><?= $real->pic ?></td>
              <td><?= $real->anggaran ?></td>
              <td><a href="<?= base_url('unit_kerja/manajemenrisk/editRTP/'.$real->id_sop) ?>" class="btn btn-success btn-md"> Realisasi </a></td>
          </tr>
      <?php  endforeach ?>
        </table>
    </div>
</div>

 <?php if($this->session->flashdata('notif') ){ ?>
                <div class="callout callout-success" id="notifications">
                <?php echo $this->session->flashdata('notif'); ?>
                </div>
                <?php } ?>