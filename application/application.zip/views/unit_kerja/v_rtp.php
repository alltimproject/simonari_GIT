
<div class="rightcolumn">
  <div class="card">
  <?php $no = 1; ?>
    <div class="contentRTP1">
       <legend>Rencana Penanganan Risiko </legend>
       <table class="table table-bordered table-hover">
         <tr class="bg-blue">
           <th>No</th>
            <th>Risiko</th>
            <th>Dampak</th>
            <th>Tingkat</th>
            <th>Pengendalian</th>
            <th>Penanganan</th>
            <th>Mulai</th>
            <th>Selesai</th>
            <th>Output</th>
            <th>PIC</th>
            <th>Anggaran</th>
            <th>Aksi</th>
         </tr>
       

      <?php foreach ($rencana as $rtp): ?>
            <tr>
              <td><?= $no++ ?></td>
              <td><?= $rtp->nama_risk ?></td>
              <td><?= $rtp->deskripsi_cause ?></td>
              <td><?= $rtp->hitung ?></td>
              <td><?= $rtp->deskripsi_pengendalian ?></td>
              <td><?= $rtp->deskripsi_rtp ?></td>
              <td><?= $rtp->plan_mulai ?></td>
              <td><?= $rtp->plan_selesai ?></td>
              <td><?= $rtp->indikator_output ?></td>
              <td><?= $rtp->pic ?></td>
              <td><?= $rtp->anggaran ?></td>
              <td><?php if(!isset($rtp->deskripsi_rtp)){ ?>
                    <a href="<?= base_url('unit_kerja/manajemenrisk/addRTP/'.$rtp->id_sop) ?>" class="btn btn-md btn-info">Buat RTP</a>
                  <?php } else { ?>
                    <a>Done <span class="fa fa-check"></span></a>
                  <?php } ?>  
              </td>
          </tr>
      <?php  endforeach ?>
        </table>
    </div>
</div>


</div>

 <?php if($this->session->flashdata('notif') ){ ?>
                <div class="callout callout-success" id="notifications">
                <?php echo $this->session->flashdata('notif'); ?>
                </div>
                <?php } ?>

