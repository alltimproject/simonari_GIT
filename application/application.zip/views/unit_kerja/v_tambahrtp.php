<?php 

	foreach ($data as $key) {
		$id_sop = $key->id_sop;
		$nama_risk = $key->nama_risk;
		$nama_sop = $key->nama_sop;
	}

 ?>

<div class="rightcolumn">
	<div class="card">
		<form action="<?= base_url('unit_kerja/manajemenrisk/saveRTP') ?>" method="post">
			<div class="form-group">
				<label>SOP</label>
				<textarea class="form-control" readonly=""><?= $nama_sop ?></textarea>
				<input name="id_sop" type="hidden" value="<?= $id_sop ?>">
			</div>
			<div class="form-group">
				<label>Risiko</label>
				<textarea class="form-control" readonly=""><?= $nama_risk ?></textarea>
			</div>
			<div class="form-group">
				<label>Deskripsi RTP</label>
				<textarea name="deskripsi_rtp" class="form-control"></textarea>
			</div>
			<div class="form-group">
				<label>Plan Mulai</label>
				<input type="date" class="form-control" name="plan_mulai">
			</div>
			<div class="form-group">
				<label>Plan Selesai</label>
				<input type="date" class="form-control" name="plan_selesai">
			</div>
			<div class="form-group">
				<label>Indikator Output</label>
				<input type="text" class="form-control" name="indikator_output">
			</div>
			<div class="form-group">
				<label>PIC</label>
				<input type="text" class="form-control" name="pic">
			</div>
			<center>
				<button type="submit" name="submit" class="btn btn-md btn-info">Save</button>
				<button type="button" name="cancel" class="btn btn-md btn-danger">Cancel</button>
			</center>
		</form>
	</div>
</div>

